/* Create skills table */
CREATE TABLE IF NOT EXISTS skills (
    `SkillID` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `Name` VARCHAR(255) NOT NULL,
    PRIMARY KEY(`SkillID`)
);

/* Create building table */
CREATE TABLE IF NOT EXISTS building (
    `BuildingID` BIGINT(20) NOT NULL AUTO_INCREMENT, 
    `Number` VARCHAR(255) NOT NULL, 
    `Street` VARCHAR(255) NOT NULL, 
    `Town` VARCHAR(255) NOT NULL, 
    `Postcode` VARCHAR(255) NOT NULL,
    PRIMARY KEY(`BuildingID`)
);

/* Create emergency contact table */
CREATE TABLE IF NOT EXISTS emergency_contact(
    `ContactID` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `FirstName` VARCHAR(255) NOT NULL, 
    `LastName` VARCHAR(255) NOT NULL, 
    `ContactNumber` VARCHAR(11) NOT NULL,
    PRIMARY KEY(`ContactID`)
); 

/* Create person table */
CREATE TABLE IF NOT EXISTS person (
    `PersonID` BIGINT(20) NOT NULL AUTO_INCREMENT, 
    `FirstName` VARCHAR(255) NOT NULL, 
    `LastName` VARCHAR(255) NOT NULL,
    `PhoneNumber` VARCHAR(11) NOT NULL,
    `EmailAddress` VARCHAR(255) NOT NULL, 
    `ContactID` BIGINT(20) NOT NULL,
    PRIMARY KEY(`PersonID`),
    FOREIGN KEY(`ContactID`) REFERENCES `emergency_contact`(`ContactID`)
);

/* Create tenant table */
CREATE TABLE IF NOT EXISTS tenant (
    `PersonID` BIGINT(20) NOT NULL, 
    `SortCode` VARCHAR(6) NOT NULL,
    `AccountNumber` VARCHAR(8) NOT NULL,
    PRIMARY KEY(`PersonID`),
    FOREIGN KEY(`PersonID`) REFERENCES `person`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create employee table */
CREATE TABLE IF NOT EXISTS employee (
    `PersonID` BIGINT(20) NOT NULL,
    `Salary` BIGINT(20) NOT NULL,
    PRIMARY KEY(`PersonID`), 
    FOREIGN KEY(`PersonID`) REFERENCES `person`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
); 

/* Create technician table */
CREATE TABLE IF NOT EXISTS technician (
    `PersonID` BIGINT(20) NOT NULL,
    PRIMARY KEY(`PersonID`),
    FOREIGN KEY(`PersonID`) REFERENCES `employee`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create manager table */
CREATE TABLE IF NOT EXISTS manager (
    `PersonID` BIGINT(20) NOT NULL,
    PRIMARY KEY(`PersonID`),
    FOREIGN KEY(`PersonID`) REFERENCES `employee`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create technician_skill table */
CREATE TABLE IF NOT EXISTS technician_skill (
    `TechnicianID` BIGINT(20) NOT NULL,
    `SkillID` BIGINT(20) NOT NULL, 
    PRIMARY KEY(`TechnicianID`, `SkillID`),
    FOREIGN KEY(`TechnicianID`) REFERENCES `technician`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(`SkillID`) REFERENCES `skills`(`SkillID`) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create apartment table */
CREATE TABLE IF NOT EXISTS apartment (
    `BuildingID` BIGINT(20) NOT NULL,
    `ApartmentNumber` BIGINT(20) NOT NULL, 
    `NumBedrooms` INT(2) NOT NULL, 
    `NumBathrooms` INT(2) NOT NULL, 
    `TotalArea` INT(10) NOT NULL,
    `ManagerID` BIGINT(20) NOT NULL, 
    PRIMARY KEY(`BuildingID`, `ApartmentNumber`), 
    FOREIGN KEY(`BuildingID`) REFERENCES `building`(`BuildingID`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(`ManagerID`) REFERENCES `manager`(`PersonID`)
);

/* Create office table */
CREATE TABLE IF NOT EXISTS office (
    `OfficeID` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `BuildingID` BIGINT(20) NOT NULL,
    `ApartmentNumber` BIGINT(20) NOT NULL,
    `ManagerID` BIGINT(20) NOT NULL UNIQUE,
    PRIMARY KEY(`OfficeID`), 
    FOREIGN KEY(`BuildingID`, `ApartmentNumber`) REFERENCES `apartment`(`BuildingID`, `ApartmentNumber`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(`ManagerID`) REFERENCES `manager`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create lease_agreement table */
CREATE TABLE IF NOT EXISTS lease_agreement (
    `LeaseID` BIGINT(20) NOT NULL AUTO_INCREMENT,
    `BuildingID` BIGINT(20) NOT NULL, 
    `ApartmentNumber` BIGINT(20) NOT NULL, 
    `StartDate` DATE NOT NULL, 
    `ExpectedDuration` INT(5) NOT NULL, 
    `MonthlyRent` INT(5) NOT NULL, 
    `ManagerID` BIGINT(20) NOT NULL,
    `Expired` TINYINT NOT NULL DEFAULT 1, 
    PRIMARY KEY(`LeaseID`),
    FOREIGN KEY(`BuildingID`, `ApartmentNumber`) REFERENCES `apartment`(`BuildingID`, `ApartmentNumber`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(`ManagerID`) REFERENCES `manager`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE
);


/* Create tenant_lease table */
CREATE TABLE IF NOT EXISTS tenant_lease (
    `PersonID` BIGINT(20) NOT NULL, 
    `LeaseID` BIGINT(20) NOT NULL,
    PRIMARY KEY(`PersonID`, `LeaseID`), 
    FOREIGN KEY(`PersonID`) REFERENCES `person`(`PersonID`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(`LeaseID`) REFERENCES `lease_agreement`(`LeaseID`) ON DELETE CASCADE ON UPDATE CASCADE
);
