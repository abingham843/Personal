/*Insert for `skills` table*/
INSERT INTO `skills`(`Name`) VALUES ("carpentry");
INSERT INTO `skills`(`Name`) VALUES ("plumbing"); 
INSERT INTO `skills`(`Name`) VALUES ("electrical");

/*Insert for `building` table*/
INSERT INTO `building`(`Number`,`Street`, `Town`, `Postcode`) VALUES ("8", "Wellesley Avenue", "Belfast", "BT9 6DG" );
INSERT INTO `building`(`Number`,`Street`, `Town`, `Postcode`) VALUES ("16", "Wolseley Street", "Belfast", "BT7 1LG" );
INSERT INTO `building`(`Number`,`Street`, `Town`, `Postcode`) VALUES ("25", "Wellington Park Ave", "Belfast", "BT9 6DT" );

/*Insert for `emergency_contact` table*/
/* does everyone need emergency contacts?*/
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Audrey", "Hannigan", "07483565734"); /* same contact Audrey */
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Liz", "MacMaster", "07483997684");/* same contact liz */
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("David", "Harbour", "07765398684");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Eliza", "Dean", "07532793672");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Audrey", "Hepburn", "07854952862");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Sam", "Smith", "07984659837"); /* contact who lives in another apt*/
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("James", "Halpert", "07483997684"); /* same contact liz */
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ( "David", "Williams", "07568466754");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Tahani", "Al-Jamil", "07768475357");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Elenor", "Shelstrop", "07483997684");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Jason", "Mendoza", "07546397684");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Beth", "Hannigan", "07483997644"); /* contact who lives in another apt*/
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Simran", "Singh", "07583997884");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Darcy", "Carden", "07883697684");
INSERT INTO `emergency_contact`(`FirstName`, `Lastname`, `ContactNumber`) VALUES ("Ted", "Dansen", "07283657687");


/*Insert for `person` table*/
/*tenants*/
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Beth", "Hannigan", "07565456787", "bhannigan1@gmail.com", 1);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Amy", "Hannigan", "07786754323", "ahannigan12@gmail.com", 1);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Lucy", "MacMaster", "07987678789", "lmacmaster22@hotmail.co.uk", 2);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Caty", "MacMaster", "07656512323", "cmacmaster4@gmail.com", 2);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Andrew", "Bingham", "07564189765", "abingham345@gmail.com", 3);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Conor", "McCann", "07787234123", "cmccann543@gmail.com", 3);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Ronan", "Monaghan", "07787634215", "rmonaghan3@hotmail.co.uk", 4);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Ross", "Johnston", "07615643894", "rjohnston55@hotmail.co.uk", 5);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Flora", "MacMaster", "07958324565", "fmacmaster06@gmail.com", 2);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Dearbhla", "Carrigan", "07432564758", "dcarrigan1@yahoo.com", 5);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Sam", "Smith", "07618564532", "ssmith9@outlook.com", 5);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Aideen", "Casey", "07385957243", "acasey33@gmail.com", 6);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Aoibh", "Haigney", "07862308964", "ahaigney5@yahoo.com", 6);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Fergal", "Sherlock", "07396168265", "fsherlock00@hotmail.co.uk", 7);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("David", "Linton", "07527587316", "dlinton2@yahoo.co.uk", 8);
/*Employee's who live in buildings*/
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("James", "McCrory", "07683270634", "jmccrory6@gmail.com", 8);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Britney", "Spears", "07965742894", "bspears45@hotmail.co.uk", 8);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Nina", "Nesbitt", "07962537907", "nnesbitt08@hotmail.co.uk", 8);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Beyonce", "Knowles", "07985463279", "bknowles@gmail.com", 9);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Kanye", "West", "07563627893", "kwest08@yahoo.com", 10);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Grace", "VanderWaal", "07562749712", "gvanderwaal123@hotmail.co.uk", 11);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("JP", "Saxe", "07529724156", "jsaxe76@gmail.com", 11);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Christopher", "Robin", "07934215743", "crobin900@gmail.com", 12);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Harry", "Potter", "07863490761", "hpotter1@hotmail.co.uk", 12);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Gabrielle", "Aplin", "07963850258", "gaplin15@hotmail.co.uk", 12);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Camila", "Cabello", "07863344676", "ccabello1@hotmail.co.uk", 12);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Alessia", "Cara", "07528639590", "acara487@yahoo.com", 12);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Skylar", "Grey", "07427614652", "sgrey4@gmail.com", 3);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Jess", "Glynne", "07418737598", "jglynne90@hotmail.co.uk", 4);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Emily", "Inglis", "07957329756", "einglis276@gmail.com", 13);
/*Employees who are managers*/
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Percy", "Jackson", "07963869455", "pjackson465@hotmail.co.uk", 14);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Hermione", "Granger", "07584225664", "hgranger265@yahoo.com", 14);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Ron", "Weasley", "07566684532", "rweasley2@hotmail.co.uk", 14);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Draco", "Malfoy", "07966457786", "dmalfoy231@gmail.com", 14);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Alicia", "MacLeod", "07836652476", "amacleod34@hotmail.co.uk", 15);
/*Employees who are just technicians*/
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Annabeth", "Chase", "07966423875", "achase07@yahoo.com", 15);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Muhammad", "Ali", "07988674634", "mali76@hotmail.co.uk", 7);
INSERT INTO `person`(`FirstName`, `LastName`, `PhoneNumber`, `EmailAddress`, `ContactID`) VALUES ("Chidi", "Anagonye", "07537876956", "canagonye546@gmail.com", 8);

/*Insert for `tenant` table*/
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (1, "12345678", "243546");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (2, "23456789", "123456");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (3, "87654321", "234567");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (4, "98765432", "345678");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (5, "56781234", "456789");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (6, "43218765", "987654");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (7, "13243546", "876543");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (8, "13245768", "765432");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (9, "97867564", "654321");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (10, "24354231", "975313");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (11, "67589439", "864246");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (12, "57468732", "646464");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (13, "43521698", "696969");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (14, "36485968", "132435");
INSERT INTO `tenant`(`PersonID`, `AccountNumber`, `SortCode`) VALUES (15, "78593623", "135797");

/*Insert for `employee` table*/
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (16, 35000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (17, 35000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (18, 40000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (19, 21000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (20, 56000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (21, 90000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (22, 100000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (23, 15000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (24, 35000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (25, 21000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (26, 21000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (27, 35000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (28, 40000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (29, 15000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (30, 120000);
/*Manager Employees make at least 2 technicians */
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (31, 50000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (32, 50000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (33, 88000);/*Manager and technician*/
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (34, 88000);/*Manager and Technician*/
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (35, 50000);
/*Technician Employees*/
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (36, 55000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (37, 55000);
INSERT INTO `employee`(`PersonID`, `Salary`) VALUES (38, 55000);

/*Insert for `technician` table*/
INSERT INTO `technician`(`PersonID`) VALUES (33);
INSERT INTO `technician`(`PersonID`) VALUES (34);
INSERT INTO `technician`(`PersonID`) VALUES (36);
INSERT INTO `technician`(`PersonID`) VALUES (37);
INSERT INTO `technician`(`PersonID`) VALUES (38);

/*Insert for `manager` table*/
INSERT INTO `manager`(`PersonID`) VALUES (31);
INSERT INTO `manager`(`PersonID`) VALUES (32);
INSERT INTO `manager`(`PersonID`) VALUES (33);
INSERT INTO `manager`(`PersonID`) VALUES (34);
INSERT INTO `manager`(`PersonID`) VALUES (35);

/*Insert for `technician_skill` table*/
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (33, 1);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (33, 2);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (34, 2);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (34, 3);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (36, 3);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (37, 1);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (37, 3);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (38, 1);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (38, 2);
INSERT INTO `technician_skill`(`TechnicianID`, `SkillID`) VALUES (38, 3);

/*Insert for `apartment` table*/
/*Building 1*/
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 101, 5, 2, 300, 31);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 102, 3, 2, 200, 31);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 103, 1, 1, 100, 31);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 104, 1, 1, 100, 32);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 105, 2, 1, 200, 32);
/*building 2*/
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 201, 4, 2, 300, 33);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 202, 4, 2, 300, 33);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 203, 2, 1, 200, 33);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 204, 1, 1, 100, 33);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 205, 1, 1, 100, 33);
/*building 3*/ 
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 301, 2, 1, 200, 34);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 302, 2, 1, 200, 35);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 303, 2, 1, 200, 35);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 304, 3, 2, 200, 35);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 305, 3, 2, 200, 35);
/*Building offices*/
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 111, 1, 1, 200, 31);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (1, 112, 1, 1, 200, 32);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (2, 222, 1, 1, 200, 33);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 333, 1, 2, 200, 34);
INSERT INTO `apartment`(`BuildingID`, `ApartmentNumber`, `NumBedrooms`, `NumBathrooms`, `TotalArea`, `ManagerID`) VALUES (3, 334, 1, 2, 200, 35);

/* Insert for `office` table*/
INSERT INTO `office`(`BuildingID`, `ApartmentNumber`, `ManagerID`) VALUES (1, 111, 31);
INSERT INTO `office`(`BuildingID`, `ApartmentNumber`, `ManagerID`) VALUES (1, 112, 32);
INSERT INTO `office`(`BuildingID`, `ApartmentNumber`, `ManagerID`) VALUES (2, 222, 33);
INSERT INTO `office`(`BuildingID`, `ApartmentNumber`, `ManagerID`) VALUES (3, 333, 34);
INSERT INTO `office`(`BuildingID`, `ApartmentNumber`, `ManagerID`) VALUES (3, 334, 35); 

/*Insert for `lease_agreement` table*/
/* Building 1 apt. leases */
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (1,101,'2019-01-01', 12, 1250, 31, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (1,102,'2019-03-01', 18, 750, 31 ,1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (1,103,'2019-02-01', 12, 250, 31, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (1,104,'2019-03-01', 6, 250, 32, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (1,105,'2019-01-01', 4, 500, 32, 1);
/*Building 2 apt. leases */
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (2,201,'2018-01-01', 24, 1000, 33, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (2,202,'2018-01-01', 12, 1000, 33, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (2,203,'2018-06-01', 24, 500, 33, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (2,204,'2018-03-01', 24, 250, 33, 1);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (2,205,'2018-01-01', 12, 250, 33, 1);
/*Building 3 apt. leases */
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (3,301,'2019-03-01', 12, 500, 34, 0);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (3,302,'2019-06-01', 24, 500, 35, 0);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (3,303,'2019-01-01', 18, 500, 35, 0);
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (3,304,'2019-01-01', 2, 0, 35, 0); /* guest */
INSERT INTO `lease_agreement`(`BuildingID`,`ApartmentNumber`, `StartDate`,`ExpectedDuration`, `MonthlyRent`, `ManagerID`, `Expired`) VALUES (3,305,'2019-01-01', 12, 750, 35, 0);

/*INSERT for `tenant_lease` table */
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (1,1);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (2,1);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (3,1);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (4,1);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (5,1);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (6,2);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (16,2);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (21,3);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (26,4);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (27,5);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (7,6);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (8,6);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (17,6);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (18,6);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (19,7);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (20,7);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (30,7);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (22,8);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (9,9);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (23,10);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (10,11);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (11,12);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (12,12);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (24,13);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (25,13);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (28,14);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (29,14);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (13,15);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (14,15);
INSERT INTO `tenant_lease`(`PersonID`,`LeaseID`) VALUES (15,15);
