
DROP TABLE IF EXISTS tenant_lease;

DROP TABLE IF EXISTS lease_agreement;

DROP TABLE IF EXISTS office;

DROP TABLE IF EXISTS apartment;

DROP TABLE IF EXISTS technician_skill;

DROP TABLE IF EXISTS manager;

DROP TABLE IF EXISTS technician;

DROP TABLE IF EXISTS employee;

DROP TABLE IF EXISTS building;

DROP TABLE IF EXISTS skills;

DROP TABLE IF EXISTS tenant;

DROP TABLE IF EXISTS person;

DROP TABLE IF EXISTS emergency_contact;