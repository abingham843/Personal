/* Query 1 */

SELECT
    person.PersonID,
    person.FirstName,
    person.LastName,
    person.PhoneNumber,
    person.EmailAddress,
    DATE_ADD(
        lease_agreement.StartDate,
        INTERVAL lease_agreement.ExpectedDuration MONTH
    ) AS ExpiryDate,
    lease_agreement.LeaseID
FROM
    person
INNER JOIN tenant_lease ON person.PersonID = tenant_lease.PersonID
INNER JOIN lease_agreement ON lease_agreement.LeaseID = tenant_lease.LeaseID
WHERE
    DATE_ADD(
        lease_agreement.StartDate,
        INTERVAL lease_agreement.ExpectedDuration MONTH
    ) BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 2 MONTH)
ORDER BY
    ExpiryDate ASC;

/* Query 2 */

SELECT
    COUNT(technician_skill.SkillID) AS "Manager number of Skills",
    person.FirstName,
    person.LastName,
    person.PersonID
FROM
    person
INNER JOIN technician ON person.PersonID = technician.PersonID
INNER JOIN manager ON person.PersonID = manager.PersonID
INNER JOIN technician_skill ON technician_skill.TechnicianID = technician.PersonID
INNER JOIN skills ON technician_skill.SkillID = skills.SkillID
GROUP BY
    person.PersonID;

/* Query 3 */

SELECT
    lease_agreement.leaseID,
    tenant_lease.PersonID
FROM
    lease_agreement
INNER JOIN tenant_lease ON lease_agreement.LeaseID = tenant_lease.LeaseID
WHERE
    tenant_lease.LeaseID IN(
    SELECT
        LeaseID
    FROM
        lease_agreement
    WHERE
        expired = 0
);

/* Query 4 */

SELECT
    person.PersonID,
    person.FirstName,
    person.LastName,
    lease_agreement.LeaseID
FROM
    person
INNER JOIN tenant_lease ON person.PersonID = tenant_lease.PersonID
INNER JOIN lease_agreement ON lease_agreement.LeaseID = tenant_lease.LeaseID
WHERE
    (lease_agreement.expired = 0);